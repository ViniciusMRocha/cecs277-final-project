package com.factory;

public enum PastryTypes {
    CROISSANT, COOKIE, MACAROON
}
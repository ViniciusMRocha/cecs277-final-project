package com.factory;

public enum DrinkTypes {
    COFFEE, TEA
}

package com.factory;

public abstract class ProductFactory {
    public Product createProduct(Object name, Object type, Object details, Object details2, Object details3, Object details4) {
        return null;
    }
}
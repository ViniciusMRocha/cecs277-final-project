package com.factory;

public enum ProductTypes {
    DRINK, PASTRY
}

package com.decorator.toppings.drinktoppings;

public enum DrinkToppings {
    COCONUT_JELLY, LYCHEE_JELLY, GRASS_JELLY, PASSIONFRUIT_JELLY,
    BOBA, POPPING_BOBA,
    WHIPPED_CREAM, STRAWBERRIES,
}